---
name: phase-completion-gate
description: |
  开发阶段完成门禁。测试绿了不等于完成，必须经过独立 Code Review 且 P0/P1 归零后
  才能标记完成。触发条件：pytest/ST 全绿之后。从 10 次复犯中提炼。
  防止"测试绿了就收工"导致的质量漏洞。
author: OpenClaw
version: 1.0.0
date: 2026-03-18
---

# Phase 完成门禁（Phase Completion Gate）

## Problem

测试绿了就直接写总结、更新进度、标记完成，跳过 Code Review，导致代码质量问题遗留到下一阶段或生产环境。

## Context / Trigger Conditions

- `pytest ... passed` 或 ST 全绿之后
- 准备标记某个开发阶段为"完成"时
- 准备更新进度文件时

## Solution

测试绿之后，下一步永远是输出门禁模板 → Code Review，不是"完成"。

### 门禁模板

```
--- Phase 完成门禁 ---
测试状态：[pytest/ST] 全绿
Code Review：[未开始/进行中/已完成，P0=X P1=X]
P0/P1 归零：[未开始/已归零]
门禁结论：[全部通过 → 可更新进度 / 未通过 → 继续处理]
---
```

### 完整流程（5 步）

1. 测试绿 → 输出门禁模板
2. 启动独立 Code Review（不能自己审自己）→ 产出 P0/P1/P2
3. 全量处置：P0/P1 必须修复；P2 逐条标注处置方案呈现给用户确认
4. 修复后全量回归 → 二次 CR → 循环直到 P0=0 P1=0
5. 归零声明（每条四步）：① 修复了什么 ② 怎么引入的 ③ 归因路径 ④ checklist 是否需更新

### CR 严格规则

- 禁止自己审自己（启动独立 agent）
- 二次 CR = 本阶段全部改动文件的完整复审，不是只看修复 diff
- 归零声明必须由独立 CR agent 确认后才能发出

## Verification

- 门禁模板已输出
- 独立 CR 已执行且 P0=0 P1=0
- 归零声明每条包含四步分析

## Example

```
--- Phase 完成门禁 ---
测试状态：pytest 12 passed
Code Review：已完成，P0=0 P1=0 P2=2
P0/P1 归零：已归零
门禁结论：全部通过 → 可更新进度
---
```

## Notes

- 最常见违规：测试绿了直接写总结
- 第二常见：自己看一眼说"没问题"，跳过独立 CR
- "循环直到归零"杜绝了"差不多就行"的心态
