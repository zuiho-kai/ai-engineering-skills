---
name: token-and-model-strategy
description: |
  AI 辅助开发的 Token 优化与模型选择策略。四层优化（知识缓存/局部加载/任务隔离/文档精简）
  实测降低 40-50% token 消耗。三层模型金字塔（Opus/Sonnet/Haiku）按任务复杂度分配。
  含 Write 工具分步写入规则（DEV-8，5 次复犯）。
author: OpenClaw
version: 1.0.0
date: 2026-03-18
---

# Token 优化与模型选择（Token & Model Strategy）

## Problem

AI 辅助开发中 token 消耗失控：全量加载文档、不分任务复杂度用同一模型、大文件一次性写入反复失败。

## Context / Trigger Conditions

- 项目文档/错题本超过 500 行时
- 需要控制 AI 开发成本时
- 选择用哪个模型处理任务时
- Write 工具写大文件失败时

## Solution

### 一、Token 优化四层策略

**第 1 层：中央知识缓存（降 15%）**
- 维护 CODE_MAP.md（模块→文件→关键函数索引）
- 新 session 先读 CODE_MAP 直达目标，不 grep 全项目
- 设计决策写入持久化记忆，不重复讨论

**第 2 层：文件级局部加载（降 10%）**
- Read 带 offset + limit，只读相关函数段
- 大文件先读结构，定位后再读具体段落
- 文档按模块拆分，按需加载

**第 3 层：任务分层隔离（降 10%）**
- 架构 session / 执行 session / 测试 session 分离
- 用 Task/Agent 启子任务，天然隔离上下文

**第 4 层：文档精简（降 10%）**
- 主配置文件控制在 100 行以内
- 详细规则放子文件，主文件只放链接
- Checklist 按任务类型按需加载

### 二、模型选择三层金字塔

| 层级 | 模型 | 占比 | 适用任务 |
|------|------|------|----------|
| 顶层 | Opus | 10-20% | 架构设计、复杂算法、跨文件重构、DevOps |
| 中层 | Sonnet | 50-60% | 单文件修改、中等逻辑、UT、评审 |
| 底层 | Haiku | 20-30% | 格式修正、重命名、文档补全、小 patch |

决策树：>3 文件/架构决策 → Opus；单模块中等逻辑 → Sonnet；纯格式/文档 → Haiku

### 三、Write 工具分步规则

- ≤50 行：一次 Write
- >50 行：Write ≤50 行骨架 + Edit 逐段填充（每段 ≤50 行）
- Write 失败 1 次 → 立即切 Bash heredoc
- 禁止同一方式连续失败超过 2 次

## Verification

- 文档加载量 < 全量的 50%
- 模型选择与任务复杂度匹配
- 无单次 Write 超 50 行的情况

## Notes

- 实测：错题本从全量 1073 行 → 按需 100-200 行，token 降 60%
- Sonnet 做 DevOps 耗时 23 分钟 vs Opus 5-8 分钟 → DevOps 用 Opus
- Haiku 做复杂逻辑返工成本 > 直接用 Sonnet
