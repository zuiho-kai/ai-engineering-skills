---
name: error-landing
description: |
  出问题自动落盘流程。通过归因决策树（A/B/C/D）把每次犯错变成流程改进，
  而不是"下次注意"。触发条件：CR 发现 P0、ST 失败、同一错误连续 2 次、
  用户指出违规。支持错题本分层存储和按需加载。
author: OpenClaw
version: 1.0.0
date: 2026-03-18
---

# 出问题自动落盘（Error Landing）

## Problem

"下次注意"是最无效的改进方式。出了问题如果只靠记忆，同样的错误会反复出现。

## Context / Trigger Conditions

- CR 发现 P0 级问题
- ST（系统测试）失败
- 同一错误连续出现 2 次
- 用户指出流程违规
- 实现与设计文档不一致

## Solution

### 归因决策树

```
问题发生
  ├─ Checklist 里有对应检查项吗？
  │   ├─ 有 → 执行了吗？
  │   │   ├─ 跳过了 → A：强化触发条件
  │   │   └─ 执行了但没拦住 → B：修改 checklist 措辞
  │   └─ 没有 → C：新增检查项
  └─ 不属于 checklist 能防的 → D：写入错题本作经验
```

### 落盘门禁模板

```
--- 落盘门禁 ---
触发原因：[CR 发现 P0 / ST 失败 / 用户指出 / ...]
归因路径：[A / B / C / D]
落盘目标：[具体文件名]
草稿预览：[完整条目内容]
checklist 修改：[需要改第 X 条 / 新增 / 不需要]
---
```

### 错题本分层结构（推荐）

```
error-books/
├── _index.md          # 速查索引
├── flow-rules.md      # 路由表
├── flow-gate.md       # 门控类错误
├── flow-code-habit.md # 代码习惯类错误
├── flow-design.md     # 设计阶段类错误
├── backend-*.md       # 后端各模块
├── frontend-*.md      # 前端各模块
└── tool-rules.md      # 工具使用类错误
```

### 按需加载策略

1. 每次必读：索引（~30 行）
2. 根据任务类型读对应流程文件
3. 根据改动模块读对应模块文件
4. 不相关的不读

## Verification

- 归因路径已确定（A/B/C/D）
- 落盘门禁模板已输出
- 条目已写入对应文件
- checklist 已按需更新

## Example

```
--- 落盘门禁 ---
触发原因：CR 发现 P0，改了 get_user 签名但 3 处调用方未更新
归因路径：A：checklist 第 2 条"Grep 全量引用"有但跳过了
落盘目标：flow-code-habit.md
草稿预览：DEV-XX：改签名必须 grep 全量引用（第 N 次复犯，强化为改前硬卡点）
checklist 修改：第 2 条加粗 + 加"硬卡点"标记
---
```

## Notes

- 实战积累 80 条错题（DEV-1 到 DEV-BUG-23）
- 最高频复犯 DEV-4（17 次）最终靠入口门禁解决
- 错题本从单文件 → 分层文件，加载 token 降 60%
