---
name: st-checklist
description: |
  系统测试（ST）执行前 checklist 和七条强制约束。防止 pytest/TestClient 冒充
  系统测试。触发条件：功能开发完成后准备做端到端验证时。
  从 DEV-33（8 次复犯）中提炼：单元测试 ≠ 系统测试。
author: OpenClaw
version: 1.0.0
date: 2026-03-18
---

# 系统测试 Checklist（ST Checklist）

## Problem

TestClient 测的是函数调用，不是系统行为。pytest 全绿不代表系统能跑通，集成问题会漏到生产。

## Context / Trigger Conditions

- 功能开发完成后、标记里程碑完成前
- 准备做端到端验证时
- 有人说"测试都过了"但没跑真实 ST 时

## Solution

### ST 七条强制约束

| # | 约束 | 正确做法 | 常见违规 |
|---|------|----------|----------|
| 1 | 真实服务器 | uvicorn 独立进程 | TestClient 内存调用 |
| 2 | 真实网络 | HTTP 请求 localhost | 函数直接调用 |
| 3 | 真实数据库 | SQLite 文件或 Postgres | 纯内存 mock |
| 4 | LLM 调用 | Agent 决策走真实 LLM | 全部 mock |
| 5 | WebSocket | websockets 库真实 TCP | starlette.testclient |
| 6 | 脚本位置 | `e2e_*.py`，python 执行 | 放 tests/ 用 pytest |
| 7 | 与 UT 区分 | `test_*.py` 是 UT | pytest 绿就跳过 ST |

### 执行前 Checklist（5 步）

1. [ ] 确认 ST 脚本存在且路径正确
2. [ ] 数据库已重置到干净状态
3. [ ] 旧服务器进程已杀掉
4. [ ] 启动服务器，健康检查通过
5. [ ] 执行 ST 脚本，收集结果

### 环境重置规则

每次 ST 前必须：删除旧数据库 / 清除缓存 / 确认端口未占用 / 重启服务器

## Verification

- 7 条约束逐条确认满足
- 5 步 checklist 全部勾选
- ST 脚本实际执行并产出结果

## Example

```bash
# 错误：用 pytest 冒充 ST
pytest tests/test_api.py  # 这是 UT，不是 ST

# 正确：启真实服务器 + 跑 E2E
uvicorn server.main:app --port 8000 &
python e2e_test_login.py
```

## Notes

- pytest 冒充 ST 复犯 8 次，是第二高频的错误
- E2E 脚本写了不跑（3 次）→ 形同虚设
- 旧服务器没重启（2 次）→ 测的是旧代码
