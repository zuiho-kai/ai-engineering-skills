---
name: llm-output-defense
description: |
  LLM 输出防御性编程规范。LLM 输出永远不可信，Pydantic model 是最后防线。
  三条硬规则：枚举字段 normalize+拒绝非法值、数值字段 coerce+范围校验、字符串 strip。
  含分支矩阵全覆盖方法论。触发条件：编写接收 LLM/AI 输出的代码时。
author: OpenClaw
version: 1.0.0
date: 2026-03-18
---

# LLM 输出防御（LLM Output Defense）

## Problem

LLM 输出是"大概率正确"，不是"一定正确"。可能返回错误枚举值、超范围数字、带空格字符串、甚至非法 JSON。不做防御 → 运行时崩溃。

## Context / Trigger Conditions

- 编写接收 LLM/AI 模型输出的代码时
- Agent 决策解析、结构化数据提取、分类/标签生成、数值评分
- 使用 Pydantic model 解析 LLM 响应时

## Solution

### 三条硬规则

**1. 枚举/有限值字段：normalize + 拒绝非法值**

```python
@field_validator("action")
@classmethod
def normalize_action(cls, v: str) -> str:
    normalized = v.strip().lower()
    valid = {"attack", "defend", "wait"}
    if normalized not in valid:
        raise ValueError(f"非法值: {v!r}, 期望: {valid}")
    return normalized
```

**2. 数值字段：coerce + 范围校验**

```python
@field_validator("value", mode="before")
@classmethod
def coerce_value(cls, v):
    return float(v)  # 处理 "0.8" 字符串

@field_validator("value")
@classmethod
def clamp_range(cls, v: float) -> float:
    if not (0.0 <= v <= 1.0):
        raise ValueError(f"超范围: {v}")
    return v
```

**3. 字符串字段：strip 空白**

```python
@field_validator("content")
@classmethod
def strip_content(cls, v: str) -> str:
    return v.strip()
```

### 防御层次

```
LLM 输出
  → JSON 解析（try/except，处理非法 JSON）
    → Pydantic 校验（类型转换 + 范围检查 + 枚举归一化）
      → 业务逻辑兜底（default/fallback 策略）
```

### 分支矩阵全覆盖

含方向/模式/状态分支的逻辑：
1. 列出所有分支组合（如 3 action × 2 mode = 6 种）
2. 逐格实现处理逻辑
3. 测试按同一矩阵逐格覆盖
4. 禁止只测 happy path

## Verification

- 所有枚举字段有 normalize validator
- 所有数值字段有 coerce + 范围校验
- 所有字符串字段有 strip
- 分支矩阵已列出且逐格覆盖

## Example

LLM 返回 `{"action": " Attack ", "score": "85"}` 时：
- `action` 经 normalize → `"attack"`（合法）
- `score` 经 coerce → `85.0`，范围校验 0-100 → 通过

## Notes

- 枚举未 normalize → "Attack"（大写）匹配失败
- 数值未 coerce → "85" 字符串类型错误
- 未处理非法 JSON → LLM 偶尔返回 markdown 包裹的 JSON
- LLM 偶尔返回 markdown 包裹 JSON → 用正则提取 JSON 块后再解析
